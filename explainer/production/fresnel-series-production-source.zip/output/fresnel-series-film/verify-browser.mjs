import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const here=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(path.resolve(here,'../../explainer/package.json'));
const {chromium}=require('playwright');
const filename=path.join(here,'fresnel-series-explainer-en.mp4');
const timeline=JSON.parse(await fsp.readFile(path.join(here,'timeline.json'),'utf8'));
const size=(await fsp.stat(filename)).size;
const html='<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:#101319}video{width:1280px;height:720px;display:block}</style></head><body><video controls muted playsinline preload="auto" src="/video.mp4"><track kind="captions" srclang="en" label="English" src="/captions.vtt"></video></body></html>';
const server=http.createServer((req,res)=>{
  if(req.url==='/'){res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'}).end(html);return;}
  if(req.url==='/captions.vtt'){res.writeHead(200,{'Content-Type':'text/vtt'});fs.createReadStream(path.join(here,'fresnel-series-captions-en.vtt')).pipe(res);return;}
  if(req.url!=='/video.mp4'){res.writeHead(404).end();return;}
  const range=req.headers.range;
  if(range){const m=/bytes=(\d+)-(\d*)/.exec(range);const start=Number(m[1]);const end=m[2]?Math.min(Number(m[2]),size-1):size-1;
    res.writeHead(206,{'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Range':`bytes ${start}-${end}/${size}`,'Content-Length':end-start+1});fs.createReadStream(filename,{start,end}).pipe(res);
  }else{res.writeHead(200,{'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Length':size});fs.createReadStream(filename).pipe(res);}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,channel:'chrome'});
const page=await browser.newPage({viewport:{width:1280,height:720}});
const errors=[];page.on('pageerror',e=>errors.push(String(e)));
try{
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.waitForFunction(()=>document.querySelector('video').readyState>=3);
  await page.evaluate(()=>document.querySelector('video').play());
  await page.waitForFunction(()=>document.querySelector('video').currentTime>.6);
  const playback=await page.evaluate(()=>{const v=document.querySelector('video');return{duration:v.duration,width:v.videoWidth,height:v.videoHeight,currentTime:v.currentTime,paused:v.paused,totalFrames:v.getVideoPlaybackQuality().totalVideoFrames,droppedFrames:v.getVideoPlaybackQuality().droppedVideoFrames};});
  const times=timeline.scenes.map(s=>Number((s.start+s.duration*.45).toFixed(3)));
  for(const t of times){
    await page.evaluate(async t=>{const v=document.querySelector('video');v.pause();v.currentTime=t;await new Promise(r=>v.addEventListener('seeked',r,{once:true}));},t);
    await page.screenshot({path:path.join(here,`browser-frame-${t.toFixed(2)}.png`)});
  }
  await page.evaluate(()=>{document.querySelector('video').textTracks[0].mode='hidden';});
  await page.waitForFunction(()=>document.querySelector('video').textTracks[0].cues?.length>0);
  const captionCues=await page.evaluate(()=>document.querySelector('video').textTracks[0].cues.length);
  const expectedCues=timeline.scenes.reduce((count,scene)=>count+scene.captions.length,0);
  if(errors.length||playback.width!==1920||playback.height!==1080||playback.paused||captionCues!==expectedCues)throw new Error('Playback verification failed');
  const result={completedAt:new Date().toISOString(),file:path.basename(filename),bytes:size,playback,seekSeconds:times,captionCues,pageErrors:errors,syntheticVoice:true,newHardwareVerification:false};
  await fsp.writeFile(path.join(here,'browser-verification.json'),JSON.stringify(result,null,2)+'\n');
  const combined=JSON.parse(await fsp.readFile(path.join(here,'verification.json'),'utf8'));
  combined.browser=result;
  await fsp.writeFile(path.join(here,'verification.json'),JSON.stringify(combined,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
