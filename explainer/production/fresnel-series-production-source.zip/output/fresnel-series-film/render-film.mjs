import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {once} from 'node:events';

const here=path.dirname(fileURLToPath(import.meta.url));
const repo=path.resolve(here,'../..');
const require=createRequire(path.join(repo,'explainer/package.json'));
const {chromium}=require('playwright');
const {createServer}=await import(pathToFileURL(require.resolve('vite')).href);
const timeline=JSON.parse(await fs.readFile(path.join(here,'timeline.json'),'utf8'));
const preview=process.argv.includes('--preview');
if(!preview&&timeline.research_status!=='approved')throw new Error('Full film requires the reviewed research/script.');
const server=await createServer({root:path.join(repo,'explainer'),configFile:false,
  optimizeDeps:{entries:[path.join(repo,'explainer/series-film-stage.html')]},
  server:{host:'127.0.0.1',port:4178,strictPort:false,hmr:false,fs:{allow:[repo]}},
  plugins:[{name:'series-film-timeline',configureServer(server){server.middlewares.use((req,res,next)=>{
    if(req.url==='/__series-film/timeline.json'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(timeline));}else next();
  });}}],logLevel:'warn'});
await server.listen();
const browser=await chromium.launch({headless:true,channel:'chrome',args:['--force-device-scale-factor=1']});
const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>{errors.push(String(e));console.error(e);});
let encoder;
try{
  await page.goto(server.resolvedUrls.local[0]+'series-film-stage.html',{waitUntil:'networkidle'});
  await page.waitForFunction(()=>window.seriesFilmReady,null,{timeout:60000});
  await page.evaluate(()=>document.fonts.ready);
  await page.waitForFunction(()=>document.querySelector('#cad')?.dataset.ready==='true',null,{timeout:60000});
  const captions=[];
  for(const scene of timeline.scenes)for(const cue of scene.captions){
    await page.evaluate(t=>window.setSeriesFilmFrame(t),(cue.start+cue.end)/2);
    const box=await page.evaluate(()=>{const r=document.querySelector('#caption').getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom};});
    if(box.x<70||box.y<908||box.bottom>1080||box.height>122)throw new Error(`Subtitle overflows: ${cue.text}`);
    captions.push({text:cue.text,...box});
  }
  await fs.writeFile(path.join(here,'layout-verification.json'),JSON.stringify({checkedCaptions:captions.length,allInsideSubtitleBand:true,maxLines:2,captions},null,2)+'\n');
  for(const scene of timeline.scenes){
    await page.evaluate(t=>window.setSeriesFilmFrame(t),scene.start+scene.duration*.45);
    await page.screenshot({path:path.join(here,`scene-${String(scene.index+1).padStart(2,'0')}.png`)});
  }
  await page.evaluate(t=>window.setSeriesFilmFrame(t),timeline.scenes[1].start+4);
  await page.evaluate(()=>{document.querySelector('#caption').textContent='Shape · Stiffness · Center of gravity · Inertia';});
  await page.screenshot({path:path.join(here,'fresnel-series-poster.png')});
  const diagnostics=[];
  for(const id of ['shape','stiffness','center-of-gravity','inertia']){
    const scene=timeline.scenes.find(s=>s.id===id);
    for(const point of [.25,.7]){
      const t=scene.start+scene.duration*point;
      await page.evaluate(t=>window.setSeriesFilmFrame(t),t);
      diagnostics.push(await page.evaluate(t=>window.getSeriesFilmState(t),t));
      await page.screenshot({path:path.join(here,`motion-${id}-${point}.png`)});
    }
  }
  const stiffness=timeline.scenes.find(s=>s.id==='stiffness');
  for(const [name,offset] of [['firm',Math.PI/.72],['soft',3*Math.PI/.72]]){
    const t=stiffness.start+offset;
    await page.evaluate(t=>window.setSeriesFilmFrame(t),t);
    diagnostics.push(await page.evaluate(t=>window.getSeriesFilmState(t),t));
    await page.screenshot({path:path.join(here,`stiffness-${name}-same-input.png`)});
  }
  const inertia=timeline.scenes.find(s=>s.id==='inertia');
  const boundary=inertia.start+inertia.duration*.5;
  const transition=[];
  for(const offset of [-1/30,0,1/30]){
    const t=boundary+offset;
    await page.evaluate(t=>window.setSeriesFilmFrame(t),t);
    transition.push(await page.evaluate(t=>window.getSeriesFilmState(t),t));
    await page.screenshot({path:path.join(here,`inertia-transition-${offset<0?'before':offset>0?'after':'center'}.png`)});
  }
  if(transition.some(s=>Math.max(...s.bodyOffsetMeters.map(Math.abs))>0.00001))throw new Error('Gesture transition is not settled');
  const firm=diagnostics.at(-2),soft=diagnostics.at(-1);
  if(Math.abs(firm.force-soft.force)>1e-9||soft.indentation<=firm.indentation||firm.angles.A!==0||soft.angles.A!==0)throw new Error('Squeeze comparison contract failed');
  await fs.writeFile(path.join(here,'motion-verification.json'),JSON.stringify({illustrative:true,sameForceDifferentIndentation:true,thumbFixedDuringStiffness:true,gestureTransitionSettled:true,transition,diagnostics},null,2)+'\n');
  if(errors.length)throw new Error(errors.join('\n'));
  if(preview)console.log('All Fresnel series chapter previews and motion samples rendered.');
  else{
    const args=['-y','-v','warning','-f','image2pipe','-framerate','30','-vcodec','mjpeg','-i','-',
      '-i',path.join(here,'narration-en.wav'),
      '-vf','scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p',
      '-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p',
      '-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
      '-c:a','aac','-b:a','160k','-movflags','+faststart','-shortest',path.join(here,'fresnel-series-explainer-en.mp4')];
    encoder=spawn('ffmpeg',args,{stdio:['pipe','inherit','inherit']});
    const complete=once(encoder,'exit');
    const frames=Math.round(timeline.duration*30),start=Date.now();
    for(let i=0;i<frames;i++){
      await page.evaluate(t=>window.setSeriesFilmFrame(t),i/30);
      if(!encoder.stdin.write(await page.screenshot({type:'jpeg',quality:93})))await once(encoder.stdin,'drain');
      if(i%300===0)console.log(`Series film ${Math.round(i/30)}/${timeline.duration.toFixed(1)}s; ${((Date.now()-start)/1000).toFixed(0)}s elapsed`);
    }
    encoder.stdin.end();const[code]=await complete;
    if(code!==0)throw new Error(`ffmpeg exited ${code}`);
    if(errors.length)throw new Error(errors.join('\n'));
    console.log('Complete English Fresnel series film rendered.');
  }
}finally{
  if(encoder&&encoder.exitCode===null)encoder.kill();
  await browser.close();await server.close();
}
