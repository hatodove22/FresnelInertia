"""Narration, delivery verification and packaging for the Fresnel series film."""
from pathlib import Path
import argparse
import asyncio
import hashlib
import json
import math
import re
import shutil
import subprocess
import wave
import zipfile

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
STORY = json.loads((ROOT/'storyboard.json').read_text(encoding='utf-8'))
STEM = 'fresnel-series'
FILM = ROOT/f'{STEM}-explainer-en.mp4'
FPS, WIDTH, HEIGHT, RATE = 30, 1920, 1080, 48000


def stamp(t):
    ms = round(t*1000)
    return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}.{ms%1000:03}'


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def draft_timeline():
    start, scenes = 0.0, []
    for index, scene in enumerate(STORY['scenes']):
        duration = scene['duration_hint']
        scenes.append({**scene, 'index':index, 'start':start, 'duration':duration, 'captions':[]})
        start += duration
    write_json(ROOT/'timeline.json', {**STORY, 'duration':start, 'fps':FPS, 'scenes':scenes})
    print(f'Draft composition timeline: {start:.1f}s; no narration generated.')


async def build_audio():
    assert STORY['research_status'] == 'approved', 'Finalize primary-source review before generating narration.'
    cache = ROOT/'audio'
    cache.mkdir(exist_ok=True)
    import edge_tts
    audio, scenes, cursor = [], [], 0.0
    for index, scene in enumerate(STORY['scenes']):
        chunks, local, captions = [np.zeros(round(.7*RATE), dtype=np.float32)], .7, []
        assert scene['lines'], f'No approved narration for {scene["id"]}'
        for line_index, line in enumerate(scene['lines']):
            key = hashlib.sha256((line+STORY['voice']+STORY['voice_rate']+STORY['voice_pitch']).encode()).hexdigest()[:12]
            path = cache/f'{index+1:02}-{line_index+1:02}-{key}.mp3'
            if not path.exists():
                for attempt in range(3):
                    try:
                        await edge_tts.Communicate(line, voice=STORY['voice'], rate=STORY['voice_rate'], pitch=STORY['voice_pitch']).save(str(path))
                        break
                    except Exception:
                        if attempt == 2: raise
                        await asyncio.sleep(2)
            raw = subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-f','f32le','-ac','1','-ar',str(RATE),'-'])
            samples = np.frombuffer(raw,dtype=np.float32).copy()
            length,parts=len(samples)/RATE,[line]
            if len(line)>116:
                words=line.split();center=len(words)//2
                candidates=[i for i in range(max(3,center-4),min(len(words)-2,center+5))
                            if len(' '.join(words[:i]))<=116 and len(' '.join(words[i:]))<=116]
                split=min(candidates,key=lambda i:abs(i-center)-(2 if words[i-1].endswith(('.',',',':')) else 0))
                parts=[' '.join(words[:split]),' '.join(words[split:])]
            offset = 0.0
            for part in parts:
                duration = length*len(part.split())/len(line.split())
                captions.append({'start':cursor+local+offset,'end':cursor+local+offset+duration,'text':part})
                offset += duration
            chunks.extend([samples,np.zeros(round(.35*RATE),dtype=np.float32)])
            local += length+.35
        target = math.ceil(max(scene.get('minimum_duration',10),local+1.1)*FPS)/FPS
        chunks.append(np.zeros(round((target-local)*RATE),dtype=np.float32))
        joined = np.concatenate(chunks)
        target = len(joined)/RATE
        scenes.append({**scene,'index':index,'start':cursor,'duration':target,'captions':captions})
        audio.append(joined)
        cursor += target
        print(f'{scene["id"]}: {target:.2f}s',flush=True)
    assert 160 <= cursor <= 270, f'Review pacing: {cursor:.2f}s outside production bounds.'
    joined = np.concatenate(audio)
    joined *= .87/max(.01,float(np.abs(joined).max()))
    with wave.open(str(ROOT/'narration-en.wav'),'wb') as stream:
        stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(RATE)
        stream.writeframes((joined*32767).astype('<i2').tobytes())
    normalized=ROOT/'narration-normalized.wav'
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(ROOT/'narration-en.wav'),'-af','loudnorm=I=-18:TP=-1.5:LRA=7','-ar',str(RATE),'-c:a','pcm_s16le',str(normalized)],check=True)
    normalized.replace(ROOT/'narration-en.wav')
    timeline={**STORY,'duration':cursor,'fps':FPS,'width':WIDTH,'height':HEIGHT,'scenes':scenes}
    write_json(ROOT/'timeline.json',timeline)
    vtt='WEBVTT\n\n'
    for scene in scenes:
        for cue in scene['captions']:
            vtt += f'{stamp(cue["start"])} --> {stamp(cue["end"])}\n{cue["text"]}\n\n'
    (ROOT/f'{STEM}-captions-en.vtt').write_text(vtt,encoding='utf-8')
    text=STORY['title']+'\n\n'+STORY['disclosure']+'\n\n'
    for scene in scenes:
        text += f'{stamp(scene["start"])}  {scene["title"]}\n'+'\n'.join(scene['lines'])+'\n\n'
    text += 'Primary sources\n'
    for source in STORY['sources']:
        text += f'{source["title"]}\n{source["url"]}\n'
    text += '\nScope and limits\n'+'\n'.join(STORY['source_limits'])+'\n'
    text += f'\nAI voice: Microsoft Edge TTS {STORY["voice"]}, rate {STORY["voice_rate"]}, pitch {STORY["voice_pitch"]}.\n'
    (ROOT/f'{STEM}-transcript-en.txt').write_text(text,encoding='utf-8')
    (ROOT/'transcript-en.md').write_text('# '+text,encoding='utf-8')
    print(f'Approved timeline: {cursor:.3f}s',flush=True)


def verify():
    timeline=json.loads((ROOT/'timeline.json').read_text(encoding='utf-8'))
    assert timeline['research_status']=='approved'
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(FILM)],text=True))
    video=next(s for s in probe['streams'] if s['codec_type']=='video')
    audio=next(s for s in probe['streams'] if s['codec_type']=='audio')
    assert video['codec_name']=='h264' and (video['width'],video['height'])==(WIDTH,HEIGHT)
    assert video['avg_frame_rate']=='30/1' and video['pix_fmt']=='yuv420p'
    assert video['color_range']=='tv' and video['color_space']=='bt709'
    assert int(video['nb_frames'])==round(timeline['duration']*FPS)
    assert audio['codec_name']=='aac'
    duration=float(probe['format']['duration'])
    assert 160<=duration<=270 and abs(duration-timeline['duration'])<.12
    assert abs(float(video['duration'])-float(audio['duration']))<.12
    decoded=subprocess.run(['ffmpeg','-v','error','-i',str(FILM),'-f','null','-'],capture_output=True,text=True)
    assert decoded.returncode==0 and not decoded.stderr.strip(),decoded.stderr
    levels=subprocess.run(['ffmpeg','-hide_banner','-i',str(FILM),'-vn','-af','volumedetect','-f','null','-'],capture_output=True,text=True)
    mean=float(re.search(r'mean_volume:\s*([-\d.]+)',levels.stderr).group(1))
    peak=float(re.search(r'max_volume:\s*([-\d.]+)',levels.stderr).group(1))
    assert -30<mean<-8 and -6<peak<0
    cues=[c for s in timeline['scenes'] for c in s['captions']]
    assert all(0<=c['start']<c['end']<=duration for c in cues)
    assert all(c['end']-c['start']>=.8 for c in cues), 'A subtitle flashes too briefly'
    assert all(cues[i]['end']<=cues[i+1]['start']+.001 for i in range(len(cues)-1))
    data=FILM.read_bytes()
    assert 0<data.find(b'moov')<data.find(b'mdat')
    paths,color_checks=[],[]
    for scene in timeline['scenes']:
        at=scene['start']+scene['duration']*.45
        path=ROOT/f'encoded-scene-{scene["index"]+1:02}.png'
        subprocess.run(['ffmpeg','-y','-v','error','-ss',str(at),'-i',str(FILM),'-frames:v','1',str(path)],check=True)
        paths.append(path)
        reference=np.array(Image.open(ROOT/f'scene-{scene["index"]+1:02}.png').convert('RGB')).astype(np.int16)
        encoded=np.array(Image.open(path).convert('RGB')).astype(np.int16)
        before,after=reference[400,5],encoded[400,5]
        assert np.max(np.abs(before-after))<=3,'Encoded background range changed'
        color_checks.append({'scene':scene['id'],'reference_background_rgb':before.tolist(),
                             'encoded_background_rgb':after.tolist(),
                             'cad_region_mean_absolute_rgb_error':round(float(np.abs(reference[278:826,966:1866]-encoded[278:826,966:1866]).mean()),3)})
    sheet=Image.new('RGB',(1280,math.ceil(len(paths)/2)*360),'#101319')
    for i,path in enumerate(paths):sheet.paste(Image.open(path).convert('RGB').resize((640,360)),((i%2)*640,(i//2)*360))
    sheet.save(ROOT/'contact-sheet.jpg',quality=94)
    result={'file':FILM.name,'bytes':len(data),'duration_s':duration,'video':{k:video[k] for k in ['codec_name','width','height','avg_frame_rate','pix_fmt','color_range','color_space','color_transfer','color_primaries','side_data_list','duration','nb_frames'] if k in video},
            'audio':{k:audio[k] for k in ['codec_name','sample_rate','channels','duration']},'full_decode':'pass','faststart':True,'mean_volume_db':mean,'peak_volume_db':peak,'subtitle_cues':len(cues),'subtitle_timing':'pass','shortest_caption_s':min(c['end']-c['start'] for c in cues),'encoded_color_comparison':color_checks,'synthetic_voice':True,'new_hardware_verification':False,'sha256':hashlib.sha256(data).hexdigest()}
    for name in ['layout-verification','motion-verification']:
        path=ROOT/f'{name}.json'
        if path.exists():result[name]=json.loads(path.read_text(encoding='utf-8'))
    write_json(ROOT/'verification.json',result)
    print(json.dumps(result,indent=2),flush=True)


def publish():
    assert STORY['research_status']=='approved'
    assert json.loads((ROOT/'verification.json').read_text(encoding='utf-8'))['full_decode']=='pass'
    media,production=REPO/'explainer/public/media',REPO/'explainer/production'
    media.mkdir(parents=True,exist_ok=True);production.mkdir(parents=True,exist_ok=True)
    for name in [FILM.name,f'{STEM}-captions-en.vtt',f'{STEM}-transcript-en.txt',f'{STEM}-poster.png']:
        shutil.copy2(ROOT/name,media/name)
    for source,name in [('README.md','FRESNEL_SERIES_VIDEO_README.md'),('transcript-en.md','fresnel-series-transcript-en.md'),('verification.json','fresnel-series-verification.json')]:
        shutil.copy2(ROOT/source,production/name)
    sources=[p for p in ROOT.iterdir() if p.suffix in ['.py','.mjs','.json','.md','.txt','.vtt','.wav']]
    sources+=list((ROOT/'audio').glob('*.mp3'))
    sources += [REPO/'explainer/series-film-stage.html',REPO/'explainer/package.json',REPO/'explainer/package-lock.json']
    sources += [REPO/'explainer/series.html',REPO/'explainer/README.md',REPO/'explainer/public/favicon.svg',
                REPO/'explainer/scripts/build-series-chapters.mjs',REPO/'explainer/scripts/verify-series.mjs',
                REPO/'explainer/public/media/fresnel-series-chapters.json',
                REPO/'explainer/production/fresnel-series-evidence.json',
                REPO/'docs/reference/34_FRESNEL_SERIES_EXPLAINER.md']
    sources+=list((REPO/'explainer/src').glob('*.css'))
    # Include shared source dependencies, exact geometry and metadata rather
    # than relying on a renderer that might change after this film is made.
    sources+=list((REPO/'explainer/src').glob('*.ts'))
    sources+=list((REPO/'explainer/public/models').glob('*.glb'))
    sources+=list((REPO/'explainer/public/models').glob('*.json'))
    archive=ROOT/'fresnel-series-production-source.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for source in sorted(set(sources)):z.write(source,source.relative_to(REPO))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name in ['explainer/src/series-film-stage.ts','explainer/src/seriesFilmModel.ts','explainer/src/seriesDevice.ts','explainer/src/deviceRig.ts',
                     'explainer/public/models/whc2025-demo.glb','explainer/public/models/whc2025-kinematics.json',
                     'explainer/scripts/build-series-chapters.mjs','explainer/production/fresnel-series-evidence.json',
                     'output/fresnel-series-film/timeline.json','output/fresnel-series-film/narration-en.wav']:
            assert name in z.namelist(),f'Missing production source {name}'
    shutil.copy2(archive,production/archive.name)
    print(f'Published separate Fresnel series assets and {archive.stat().st_size}-byte source ZIP. Earlier films preserved.')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for flag in ['draft-timeline','audio','verify','publish']:parser.add_argument('--'+flag,action='store_true')
    args=parser.parse_args()
    if args.draft_timeline:draft_timeline()
    if args.audio:asyncio.run(build_audio())
    if args.verify:verify()
    if args.publish:publish()
