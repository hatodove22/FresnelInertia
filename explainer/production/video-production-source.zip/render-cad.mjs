import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const here=path.dirname(fileURLToPath(import.meta.url));
const repo=path.resolve(here,'../..');
const require=createRequire(path.join(repo,'webxr/package.json'));
const {chromium}=require('playwright');
const frames=path.join(here,'cad-frames');await fs.mkdir(frames,{recursive:true});
const server=http.createServer(async(req,res)=>{try{let name=decodeURIComponent(req.url.split('?')[0]);let file;
if(name==='/')file=path.join(here,'cad-stage.html');
else if(name.startsWith('/three/'))file=path.join(repo,'webxr/node_modules/three',name.slice(7));
else if(name==='/assets/device-cad.glb')file=path.join(repo,'output/explainer-assets/device-cad.glb');
else{res.writeHead(404).end();return;}
const data=await fs.readFile(file);const ext=path.extname(file);res.writeHead(200,{'Content-Type':ext==='.js'?'text/javascript':ext==='.html'?'text/html':'model/gltf-binary'});res.end(data);
}catch(e){res.writeHead(500).end(String(e));}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1000,height:630},deviceScaleFactor:1});
page.on('pageerror',e=>console.error(e));
try{
await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>window.ready);
const count=process.argv.includes('--preview')?1:360;
for(let i=0;i<count;i++){await page.evaluate(t=>window.frame(t),i/30);await page.screenshot({path:path.join(frames,`${String(i).padStart(4,'0')}.png`),omitBackground:true});if(i%60===0)console.log(`CAD frame ${i}/${count}`);}
}finally{await browser.close();server.close();}
