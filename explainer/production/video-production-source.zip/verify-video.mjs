import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const here=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(path.resolve(here,'../../webxr/package.json'));
const {chromium}=require('playwright');
const filename=path.join(here,'container-haptics-explainer-ja.mp4');
const size=(await fsp.stat(filename)).size;
const html='<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:#101116}video{width:1280px;height:720px;display:block}</style></head><body><video controls muted playsinline preload="auto" src="/video.mp4"></video></body></html>';
const server=http.createServer((req,res)=>{
if(req.url==='/'){res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'}).end(html);return;}
if(req.url!=='/video.mp4'){res.writeHead(404).end();return;}
const range=req.headers.range;
if(range){const m=/bytes=(\d+)-(\d*)/.exec(range);const start=Number(m[1]);const end=m[2]?Math.min(Number(m[2]),size-1):size-1;
res.writeHead(206,{'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Range':`bytes ${start}-${end}/${size}`,'Content-Length':end-start+1});fs.createReadStream(filename,{start,end}).pipe(res);
}else{res.writeHead(200,{'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Length':size});fs.createReadStream(filename).pipe(res);}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1280,height:720}});const errors=[];page.on('pageerror',e=>errors.push(String(e)));
try{
await page.goto(`http://127.0.0.1:${server.address().port}/`);
await page.waitForFunction(()=>document.querySelector('video').readyState>=3);
await page.evaluate(()=>document.querySelector('video').play());
await page.waitForFunction(()=>document.querySelector('video').currentTime>.6);
const playback=await page.evaluate(()=>{let v=document.querySelector('video');return {duration:v.duration,width:v.videoWidth,height:v.videoHeight,currentTime:v.currentTime,paused:v.paused,quality:v.getVideoPlaybackQuality().toJSON?.()??{totalVideoFrames:v.getVideoPlaybackQuality().totalVideoFrames,droppedVideoFrames:v.getVideoPlaybackQuality().droppedVideoFrames}};});
const times=[5,46,75,102];
for(const t of times){await page.evaluate(async t=>{let v=document.querySelector('video');v.pause();v.currentTime=t;await new Promise(r=>v.addEventListener('seeked',r,{once:true}));},t);await page.screenshot({path:path.join(here,`encoded-frame-${t}.png`)});}
const result={completedAt:new Date().toISOString(),file:path.basename(filename),bytes:size,playback,seekSeconds:times,pageErrors:errors,syntheticVoice:true,newHardwareVerification:false};
await fsp.writeFile(path.join(here,'verification.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
if(errors.length||!playback.width||playback.paused)throw new Error('Playback verification failed');
}finally{await browser.close();server.close();}
