"""Reproducible Japanese explainer. Requires Pillow, numpy, edge-tts, ffmpeg.

All visuals are original illustrative motion graphics, not hardware recordings.
Run: python create_video.py --audio; python create_video.py --preview;
     python create_video.py --render
"""
from pathlib import Path
import argparse, asyncio, hashlib, json, math, subprocess, wave, textwrap, time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
W, H, FPS = 1920, 1080, 30
BG, PANEL, WHITE, MUTED, ORANGE, TEAL = '#101116','#1b1d24','#f5f1e8','#a6a7ad','#ff673d','#65ddd0'
FONT = Path('C:/Windows/Fonts/YuGothB.ttc')
FONT_REG = Path('C:/Windows/Fonts/YuGothM.ttc')
FONT_LATIN = Path('C:/Windows/Fonts/bahnschrift.ttf')
SCENES = [
 dict(kicker='01 / THE IDEA', title='「中身」を、指先に。', sub='2つの傾斜面 × 4つの振動子',
      lines=['空っぽの容器に、中身があるような感覚を。', '二つの指先の傾きと、四つの振動を重ねて、動く中身の手がかりをつくります。']),
 dict(kicker='02 / ONE SHARED STATE', title='すべては、同じ中身から。', sub='手の動き → 容器内の状態 → 触覚',
      lines=['手の動きから、容器内の位置や速度を計算します。', '寸法や充填率も応答を変えます。触覚の運動モデルは、本体のエックス・ワイ断面です。']),
 dict(kicker='03 / TWO COMPLEMENTARY OUTPUTS', title='ゆっくり、傾く。瞬間に、響く。', sub='同じ状態を、異なる時間の手がかりへ',
      lines=['方向や慣性の手がかりは、二つの指先の接触面の傾きへ。', '衝突や流れ、質感は四つの振動子へ。同じ中身から、二つの出力を生みます。']),
 dict(kicker='04 / THE HAPTIC PIPELINE', title='動きを、触れる信号へ。', sub='4層の生成処理 ＋ 4チャンネルへの空間配置',
      lines=['中身の運動から、壁に触れた瞬間を検出。', '短い質感をつくり、振動子の再生信号に変換。最後に、四つの出力へ配置します。']),
 dict(kicker='05 / SPATIAL RENDERING', title='どこで、触れたか。', sub='接触する壁と、流れる方向を伝える',
      lines=['衝突した壁を中心に、振動を配ります。', '流れは、隣り合う壁に時間をずらして送ります。強さだけでなく、順序も手がかりです。']),
 dict(kicker='06 / MATERIAL EXPRESSION', title='同じ仕組みで、中身が変わる。', sub='素材を変えても、4層の道筋は共通',
      lines=['ビー玉なら、壁にコツン。砂なら、小さな接触が重なります。', '液体は、揺れと流れを表現します。その自然さは、今後も調整する部分です。']),
 dict(kicker='07 / ON-DEVICE + HAPTIC LINK', title='計算は、手の中で。', sub='AtomS3が触覚を生成し、Webが同じ状態を映す',
      lines=['触覚の計算は、手の中のアトム・エス・スリーで行います。', 'ハプティック・リンクで、ウェブが設定を送り、デバイスが返す状態を表示します。']),
 dict(kicker='08 / WORKING TODAY, NEXT TOMORROW', title='見える中身と、感じる中身。', sub='同じ状態が、体験をつなぐ。',
      lines=['傾斜と振動、デスクトップ表示の連動は、実機で確認しています。', '次は調整スタジオ、そしてアンドロイドの拡張現実へ。ここからは、今後の計画です。']),
]

font_cache = {}
def font(size, latin=False, regular=False):
    key=(size,latin,regular)
    if key not in font_cache:
        font_cache[key]=ImageFont.truetype(str(FONT_LATIN if latin else FONT_REG if regular else FONT),size)
    return font_cache[key]
def rgb(c): return tuple(int(c[i:i+2],16) for i in (1,3,5)) if isinstance(c,str) else c
def blend(a,b,t): return tuple(round(x+(y-x)*t) for x,y in zip(rgb(a),rgb(b)))
def smooth(t): t=max(0,min(1,t)); return t*t*(3-2*t)
def label(draw,xy,s,size=30,fill=WHITE,latin=False,anchor=None,regular=False):
    draw.text(xy,s,font=font(size,latin,regular),fill=fill,anchor=anchor,stroke_width=0)
def centered(draw,xy,s,size=30,fill=WHITE,latin=False): label(draw,xy,s,size,fill,latin,'mm')
def line(draw,pts,fill=MUTED,width=3): draw.line(pts,fill=fill,width=width,joint='curve')
def arrow(draw,a,b,fill=ORANGE,width=4,head=15):
    line(draw,[a,b],fill,width)
    th=math.atan2(b[1]-a[1],b[0]-a[0]); p=0.48
    draw.polygon([b,(b[0]-head*math.cos(th-p),b[1]-head*math.sin(th-p)),(b[0]-head*math.cos(th+p),b[1]-head*math.sin(th+p))],fill=fill)
def roundbox(draw,box,fill=PANEL,r=20,outline=None,width=2): draw.rounded_rectangle(box,radius=r,fill=fill,outline=outline,width=width)
def pulse(draw,x,y,r,t,color=ORANGE):
    for n in range(3):
        p=(t*0.7+n/3)%1; rr=r+p*50
        draw.ellipse((x-rr,y-rr,x+rr,y+rr),outline=blend(color,BG,p),width=max(1,int(4*(1-p))))
def dot(draw,x,y,r=7,color=ORANGE): draw.ellipse((x-r,y-r,x+r,y+r),fill=color)

# Pixel-lit spheres are cached and composited as original procedural illustrations.
sphere_cache={}
def sphere(im,center,r=65,color=ORANGE):
    key=(r,color)
    if key not in sphere_cache:
        yy,xx=np.mgrid[-r:r+1,-r:r+1]; q=(xx*xx+yy*yy)/(r*r); z=np.sqrt(np.maximum(0,1-q))
        shade=np.clip(.18+.8*(-xx/r*.45-yy/r*.58+z*.75),.12,1)
        base=np.array(rgb(color)); arr=np.empty((*q.shape,4),dtype=np.uint8)
        for c in range(3): arr[:,:,c]=np.clip(base[c]*shade+70*np.maximum(0,shade-.82),0,255)
        arr[:,:,3]=(q<=1)*255
        sphere_cache[key]=Image.fromarray(arr)
    im.paste(sphere_cache[key],(round(center[0]-r),round(center[1]-r)),sphere_cache[key])

def plate(draw,cx,cy,ang=0,color=ORANGE,w=190):
    a=math.radians(ang); ux,uy=math.cos(a),math.sin(a); vx,vy=-uy,ux
    pts=[(cx+u*ux+v*vx,cy+u*uy+v*vy) for u,v in [(-w/2,-12),(w/2,-12),(w/2,12),(-w/2,12)]]
    draw.polygon(pts,fill=color); dot(draw,cx,cy,7,WHITE)
    line(draw,[(cx,cy+16),(cx,cy+75)],MUTED,6)
    roundbox(draw,(cx-31,cy+65,cx+31,cy+115),blend(PANEL,WHITE,.08),10,outline='#50515b')

def container(im,draw,cx,cy,t,scale=1,material='marble',wire=True):
    w,h=410*scale,300*scale; x0,y0=cx-w/2,cy-h/2; x1,y1=cx+w/2,cy+h/2
    dx,dy=88*scale,-68*scale
    # Far faces and fine construction geometry.
    draw.polygon([(x0,y0),(x0+dx,y0+dy),(x1+dx,y0+dy),(x1,y0)],fill='#272a33',outline='#53555d')
    draw.polygon([(x1,y0),(x1+dx,y0+dy),(x1+dx,y1+dy),(x1,y1)],fill='#181b23',outline='#53555d')
    draw.rectangle((x0,y0,x1,y1),fill='#1b1e26')
    for j in range(1,5): line(draw,[(x0,y0+j*h/5),(x1,y0+j*h/5)],'#282b33',1)
    if material=='marble':
        xx=cx+math.sin(t*.95)*w*.32; yy=y1-55*scale-abs(math.sin(t*.95))*12*scale
        line(draw,[(cx+math.sin(t*.95-.1*k)*w*.32,y1-50*scale) for k in range(1,17)],'#55403a',max(2,int(3*scale)))
        sphere(im,(xx,yy),max(10,int(49*scale))); draw=ImageDraw.Draw(im)
        if abs(math.sin(t*.95))>.94: pulse(draw,xx,yy,52*scale,t*3)
    elif material=='sand':
        rng=np.random.default_rng(330); slope=math.sin(t)*.2
        for _ in range(190):
            rx=rng.uniform(-.46,.46)*w; ry=rng.uniform(0,.34)*h
            yy=y1-12*scale-ry+slope*rx
            xx=cx+rx+math.sin(t*2+ry)*3*scale
            dot(draw,xx,min(y1-7*scale,yy),max(2,round(rng.uniform(2,5)*scale)),blend('#a87838','#ffd693',rng.random()))
    else:
        surface=[]
        for x in np.linspace(x0+2,x1-2,70):
            q=(x-cx)/w; yy=cy+25*scale+math.sin(t)*q*70*scale+math.sin(q*10+t*2)*9*scale
            surface.append((x,yy))
        draw.polygon(surface+[(x1-2,y1-2),(x0+2,y1-2)],fill='#214842')
        line(draw,surface,TEAL,max(2,int(4*scale)))
        for k in range(3):
            line(draw,[(x, y+25*scale*(k+1)) for x,y in surface],blend('#214842',TEAL,.15),2)
    line(draw,[(x0,y0),(x1,y0),(x1,y1),(x0,y1),(x0,y0)],'#a1a1a6',max(2,int(3*scale)))
    line(draw,[(x0,y0),(x0+dx,y0+dy),(x1+dx,y0+dy),(x1+dx,y1+dy),(x1,y1)],'#767882',max(2,int(2*scale)))
    return x0,y0,x1,y1

def signal(draw,box,t,kind='slow',color=ORANGE):
    x0,y0,x1,y1=box; cy=(y0+y1)/2
    line(draw,[(x0,cy),(x1,cy)],'#42434b',2)
    pts=[]
    for x in range(int(x0),int(x1)+1,3):
        q=(x-x0)/(x1-x0)
        if kind=='slow': y=math.sin(q*math.pi*3-t)*.35
        else:
            envelope=sum(math.exp(-((q-z)/.042)**2) for z in [.18,.49,.82])
            y=math.sin(q*170-t*3)*envelope*.37
        pts.append((x,cy+y*(y1-y0)))
    line(draw,pts,color,3)

def base(scene,t,total,global_t):
    im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    # Quiet geometry and consistent editorial frame.
    for x in range(80,W,80):
        for y in range(80,890,80): dot(d,x,y,1,'#2c2d34')
    label(d,(80,45),'CONTAINER / HAPTICS',25,MUTED,True)
    label(d,(1840,45),'PRINCIPLE FILM',25,MUTED,True,anchor='ra')
    d.rectangle((80,101,1840,103),fill='#34353d')
    label(d,(80,136),scene['kicker'],25,ORANGE,True)
    label(d,(80,186),scene['title'],69)
    label(d,(84,284),scene['sub'],29,MUTED)
    # Playback progress is a graphic, not a live measurement.
    d.rectangle((80,1062,1840,1065),fill='#34353d')
    d.rectangle((80,1062,80+1760*global_t/total,1065),fill=ORANGE)
    label(d,(80,868),'原理解説の模式アニメーション / 実機の記録映像ではありません',21,'#80828c')
    label(d,(1840,868),'日本語音声：AI合成',21,'#80828c',anchor='ra')
    return im,d

def render_frame(idx,t,duration,global_t,total,caption=''):
    s=SCENES[idx]; im,d=base(s,t,total,global_t)
    if idx==0:
        label(d,(85,405),'2',205,ORANGE,True)
        label(d,(232,455),'+',120,WHITE,True)
        label(d,(325,405),'4',205,WHITE,True)
        label(d,(96,636),'TILT',30,ORANGE,True); label(d,(348,636),'VIBRATION',30,WHITE,True)
        label(d,(92,733),'動き・重さの手がかり・質感',29,MUTED)
        cadfile=ROOT/'cad-frames'/f'{min(359,round(t*FPS)):04d}.png'
        if cadfile.exists():
            cad=Image.open(cadfile).convert('RGBA').resize((900,567),Image.Resampling.LANCZOS);im.paste(cad,(870,245),cad);d=ImageDraw.Draw(im)
            dot(d,1613,541,9,ORANGE);label(d,(1640,520),'傾斜面',32,ORANGE)
            dot(d,1613,631,9,TEAL);label(d,(1640,610),'振動子',32,TEAL)
            label(d,(1000,820),'Fusion CAD 由来の機構形状',23,MUTED)
        else:
            container(im,d,1280,600,t,1.18)
            d=ImageDraw.Draw(im)
            plate(d,950,671,-15*math.sin(t*.95),w=150)
            plate(d,1690,671,15*math.sin(t*.95+.35),w=150)
            label(d,(905,806),'親指',24,MUTED); label(d,(1648,806),'人差し指',24,MUTED)
            for x,y in [(1220,390),(1490,415),(1180,776),(1460,748)]:
                dot(d,x,y,18,ORANGE); pulse(d,x,y,20,t*.8)
    elif idx==1:
        roundbox(d,(85,386,455,752),PANEL,22)
        centered(d,(270,438),'IMU',48,WHITE,True)
        cx,cy=270,555; th=math.sin(t*.8)*.23
        pts=[(cx+x*math.cos(th)-y*math.sin(th),cy+x*math.sin(th)+y*math.cos(th)) for x,y in [(-67,-47),(67,-47),(67,47),(-67,47),(-67,-47)]]
        line(d,pts,ORANGE,6); arrow(d,(cx,cy+65),(cx+math.sin(t*.8)*55,cy+116),TEAL)
        centered(d,(270,699),'手の傾き・加速度',27,MUTED)
        arrow(d,(480,568),(608,568),ORANGE,4)
        roundbox(d,(635,386,1285,752),PANEL,22,outline='#55505a')
        label(d,(669,414),'SHARED CONTENT STATE',26,ORANGE,True)
        xx=960+math.sin(t*.8)*205; yy=610+math.cos(t*.8)*35
        line(d,[(720,485),(1200,485),(1200,670),(720,670),(720,485)],'#747782',3)
        sphere(im,(xx,yy),36); d=ImageDraw.Draw(im)
        arrow(d,(xx,yy-52),(xx+math.cos(t*.8)*73,yy-52),TEAL,3)
        centered(d,(960,713),'位置 / 速度 / 接触 / 素材',28,WHITE)
        arrow(d,(1310,568),(1440,568),ORANGE,4)
        centered(d,(1660,487),'共通の状態',40)
        centered(d,(1660,560),'傾斜 ＋ 振動',39,ORANGE)
        centered(d,(1660,637),'＋ 画面表示',33,MUTED)
        label(d,(651,788),'body x/y の縮約モデル',29,MUTED)
    elif idx==2:
        roundbox(d,(85,382,940,820),PANEL,24)
        roundbox(d,(974,382,1838,820),PANEL,24)
        label(d,(115,410),'SUSTAINED DIRECTION',24,ORANGE,True)
        label(d,(1005,410),'CONTACT + TEXTURE',24,TEAL,True)
        plate(d,330,546,20*math.sin(t*.75)+10*math.cos(t*.5),w=190)
        plate(d,683,546,20*math.sin(t*.75)-10*math.cos(t*.5),w=190)
        centered(d,(330,688),'親指',26,MUTED); centered(d,(683,688),'人差し指',26,MUTED)
        label(d,(114,467),'2 × XL330',36)
        for j,(x,y) in enumerate([(1205,545),(1460,507),(1655,555),(1440,640)]):
            p=(t*1.2-j*.2)%1; col=blend('#333a40',TEAL,max(0,1-p*2))
            dot(d,x,y,39,col); pulse(d,x,y,43,t-j*.18,TEAL)
        signal(d,(116,730,910,796),t,'slow',ORANGE)
        signal(d,(1004,730,1808,796),t,'impact',TEAL)
    elif idx==3:
        names=[('01','Mass Motion','中身が動く'),('02','Event','接触を検出'),('03','Texture','質感を合成'),('04','Resonance','再生信号へ'),('+','Spatial4','4出力へ配置')]
        active=int((t*.7)%5)
        for j,(n,en,jp) in enumerate(names):
            x=84+j*355; fill=blend(PANEL,ORANGE,.13) if j==active else PANEL
            roundbox(d,(x,400,x+327,611),fill,20,ORANGE if j==active else '#42444d',2)
            label(d,(x+24,421),n,34,ORANGE,True); label(d,(x+24,478),en,32,WHITE,True);label(d,(x+24,541),jp,27,MUTED)
            if j<4: arrow(d,(x+332,506),(x+351,506),ORANGE,2,9)
        # Visual transformation: smooth trajectory becomes impact train and carriers.
        signal(d,(105,662,620,761),t,'slow',ORANGE)
        arrow(d,(655,714),(734,714),MUTED,3)
        signal(d,(770,654,1807,773),t,'impact',TEAL)
        label(d,(106,794),'状態の変化',24,MUTED); label(d,(776,794),'接触に対応する短い信号',24,MUTED)
    elif idx==4:
        cx,cy=668,610
        roundbox(d,(455,430,875,790),PANEL,20,outline='#6a6c78')
        positions=[(425,610),(905,610),(665,399),(665,790)]
        names=['Front / CH1','Back / CH2','Top / CH3','Bottom / CH4']
        # Illustrated order uses physical adjacency: Front -> Top -> Back -> Bottom.
        route=[0,2,1,3]; at=t*.6; k=int(at)%4; q=at%1
        current=route[k]; nxt=route[(k+1)%4]
        for j,(x,y) in enumerate(positions):
            intensity=max(0,1-q*1.7) if j==current else max(0,(q-.55)*1.6) if j==nxt else 0
            dot(d,x,y,36,blend('#363843',ORANGE,intensity))
            if intensity>.1: pulse(d,x,y,40,t*1.1)
        x,y=positions[current]; x2,y2=positions[nxt]
        arrow(d,(x*.78+cx*.22,y*.78+cy*.22),(x2*.78+cx*.22,y2*.78+cy*.22),TEAL,4)
        sphere(im,(cx+math.sin(t*.9)*128,cy+math.cos(t*.9)*94),35);d=ImageDraw.Draw(im)
        label(d,(180,595),names[0],24,MUTED,True);label(d,(962,595),names[1],24,MUTED,True)
        centered(d,(665,357),names[2],24,MUTED,True)
        centered(d,(665,849),names[3],22,MUTED,True)
        label(d,(1205,407),'位置',72,ORANGE)
        label(d,(1207,511),'＋',48,MUTED)
        label(d,(1205,602),'時間差',72,TEAL)
        label(d,(1207,734),'壁ラベルは出力順の定義',24,MUTED)
        label(d,(1207,777),'図の配置・波形は模式表現',24,MUTED)
    elif idx==5:
        entries=[(330,'marble','MARBLE','コツン。',ORANGE),(930,'sand','SAND','さらさら。','#e6bd78'),(1530,'water','LIQUID','ゆらり。',TEAL)]
        for cx,mat,en,jp,col in entries:
            label(d,(cx-195,344),en,29,col,True)
            container(im,d,cx,572,t,.86,mat);d=ImageDraw.Draw(im)
            centered(d,(cx,791),jp,42,WHITE)
    elif idx==6:
        # Main causal diagram has explicit intent upstream and reported state downstream.
        roundbox(d,(84,408,637,780),PANEL,24,outline='#504547')
        centered(d,(360,455),'HANDHELD DEVICE',25,ORANGE,True)
        roundbox(d,(126,496,309,665),'#302623',17,ORANGE,2)
        centered(d,(216,554),'AtomS3',37,WHITE,True);centered(d,(216,613),'触覚を計算',24,MUTED)
        arrow(d,(329,567),(379,567),ORANGE,3)
        centered(d,(508,543),'2 TILT',31,WHITE,True);centered(d,(508,598),'4 VIBRATION',25,WHITE,True)
        centered(d,(360,735),'中身の状態・アクチュエーター制御',24,MUTED)
        arrow(d,(655,555),(916,555),ORANGE,4)
        arrow(d,(916,653),(655,653),TEAL,4)
        centered(d,(786,513),'ESP-NOW',27,MUTED,True)
        for n in range(3): dot(d,675+((t*.25+n/3)%1)*222,555,6,ORANGE)
        roundbox(d,(938,474,1197,724),PANEL,20,outline='#595a64')
        centered(d,(1068,539),'StampC5',38,WHITE,True)
        centered(d,(1068,615),'USB ドングル',26,MUTED)
        line(d,[(1215,601),(1340,601)],MUTED,3);centered(d,(1270,561),'USB',25,MUTED,True)
        roundbox(d,(1360,408,1836,780),PANEL,24)
        centered(d,(1598,461),'WEB CLIENT',28,TEAL,True)
        container(im,d,1585,616,t,.46);d=ImageDraw.Draw(im)
        centered(d,(1598,749),'適用された状態を表示',24,MUTED)
        label(d,(674,694),'← 設定 / 状態 →',22,MUTED)
        label(d,(943,785),'Haptic Link',25,ORANGE,True)
    else:
        roundbox(d,(85,396,950,790),PANEL,24)
        label(d,(123,431),'CONFIRMED / DESKTOP',29,ORANGE,True)
        for j,txt in enumerate(['傾斜 ＋ 4ch振動の同時動作','画面と触覚の方向の一致','デバイスが返す適用状態の表示']):
            y=507+j*78; dot(d,143,y+17,8,ORANGE);label(d,(172,y),txt,31,WHITE)
        label(d,(122,747),'実機確認の記録：2026-09-05',23,MUTED)
        label(d,(1043,428),'NEXT / PLANNED',29,TEAL,True)
        label(d,(1043,498),'調整スタジオ',49,WHITE)
        arrow(d,(1050,590),(1780,590),TEAL,3)
        label(d,(1043,631),'Android AR',64,WHITE,True)
        label(d,(1044,733),'端末での統合動作は今後検証',28,MUTED)
    # Subtitles use a stable opaque band and respect a broadcast-safe margin.
    d.rectangle((0,909,W,1050),fill='#14151b')
    if caption:
        chunks=textwrap.wrap(caption,width=44,break_long_words=True,break_on_hyphens=False)
        chunks=chunks[:2]
        for j,txt in enumerate(chunks): centered(d,(960,953+j*51),txt,33,WHITE)
    return im

def probe_duration(path):
    return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)],text=True).strip())

async def build_audio():
    import edge_tts
    (ROOT/'audio').mkdir(exist_ok=True)
    timeline=[]; cursor=0; sr=48000; audio_all=[]
    for i,s in enumerate(SCENES):
        chunks=[]; entries=[]; local=0.6
        chunks.append(np.zeros(round(sr*.6),dtype=np.float32))
        for j,txt in enumerate(s['lines']):
            digest=hashlib.sha256((txt+'+13%').encode()).hexdigest()[:8]
            mp3=ROOT/'audio'/f'{i+1:02d}-{j+1}-{digest}.mp3'
            if not mp3.exists():
                for attempt in range(3):
                    try:
                        await edge_tts.Communicate(txt,voice='ja-JP-NanamiNeural',rate='+13%',pitch='-1Hz').save(str(mp3));break
                    except Exception:
                        if attempt==2: raise
                        await asyncio.sleep(3)
            raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(mp3),'-f','f32le','-ac','1','-ar',str(sr),'-'])
            samples=np.frombuffer(raw,dtype=np.float32).copy();dur=len(samples)/sr
            entries.append(dict(start=cursor+local,end=cursor+local+dur,text=txt))
            local+=dur+.25;chunks.extend([samples,np.zeros(round(sr*.25),dtype=np.float32)])
        # Give each scene a short reading beat; align boundaries to video frames.
        target=max(9.6,local+.20);target=math.ceil(target*FPS)/FPS
        chunks.append(np.zeros(max(0,round((target-local)*sr)),dtype=np.float32))
        scene_audio=np.concatenate(chunks);target=len(scene_audio)/sr
        timeline.append(dict(index=i,start=cursor,duration=target,captions=entries));cursor+=target;audio_all.append(scene_audio)
        print(f'Audio scene {i+1}: {target:.2f}s',flush=True)
    full=np.concatenate(audio_all)
    peak=np.max(np.abs(full));full=full*.88/max(.01,peak)
    # Quiet original ambient bed. Deliberately not a recorded device signal.
    tt=np.arange(len(full))/sr
    bed=(np.sin(2*np.pi*110*tt)*.004+np.sin(2*np.pi*164.81*tt)*.0025+np.sin(2*np.pi*220*tt)*.0015)
    envelope=np.minimum(1,tt/3)*np.minimum(1,(cursor-tt)/3)
    out=np.clip(full+bed*envelope,-1,1)
    with wave.open(str(ROOT/'narration.wav'),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes((out*32767).astype('<i2').tobytes())
    data=dict(duration=cursor,fps=FPS,width=W,height=H,voice='ja-JP-NanamiNeural',voice_disclosure='日本語音声はAI合成です。',scenes=timeline)
    (ROOT/'timeline.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    def stamp(x):
        ms=round(x*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}.{ms%1000:03}'
    vtt='WEBVTT\n\n'
    for scene in timeline:
        for entry in scene['captions']: vtt+=f"{stamp(entry['start'])} --> {stamp(entry['end'])}\n{entry['text']}\n\n"
    (ROOT/'captions-ja.vtt').write_text(vtt,encoding='utf-8')
    transcript='# 「中身」を、指先に。— 動作原理\n\n日本語音声はAI合成（Microsoft Edge TTS / ja-JP-NanamiNeural）。\n模式アニメーションであり、実機の記録・計測映像ではありません。\n\n'
    for s in SCENES:transcript+=f"## {s['kicker']} — {s['title']}\n\n"+'\n\n'.join(s['lines'])+'\n\n'
    transcript+='## 事実確認の出典\n\n- docs/00_DESIGN_SPECIFICATION.md\n- docs/16_PROGRESS_STATUS.md（2026-09-05）\n- docs/04_HARDWARE_AND_PIN_SPEC.md\n- docs/reference/03_PIPELINE_SPEC.md\n- docs/reference/14_TILT_PSEUDOFORCE_SPEC_REV2.md\n\n数値・波形・動きは測定データではありません。現在のモデルはbody x/yの縮約モデル。握力は固定の公称値で、FSR計測は未実装。Android ARと調整スタジオは計画段階です。\n'
    (ROOT/'transcript-ja.md').write_text(transcript,encoding='utf-8')

def get_timeline():
    if (ROOT/'timeline.json').exists():return json.loads((ROOT/'timeline.json').read_text(encoding='utf-8'))
    return dict(duration=104,scenes=[dict(index=i,start=i*13,duration=13,captions=[dict(start=i*13,end=(i+1)*13,text=s['lines'][0])]) for i,s in enumerate(SCENES)])
def caption_at(scene,t):
    return next((c['text'] for c in scene['captions'] if c['start']<=t<c['end']),'')
def previews():
    data=get_timeline();frames=[]
    for s in data['scenes']:
        t=s['start']+s['duration']*.42
        frame=render_frame(s['index'],s['duration']*.42,s['duration'],t,data['duration'],caption_at(s,t))
        frame.save(ROOT/f"scene-{s['index']+1:02d}.png")
        thumb=frame.resize((640,360));frames.append(thumb)
    sheet=Image.new('RGB',(1280,4*360),BG)
    for i,im in enumerate(frames):sheet.paste(im,((i%2)*640,(i//2)*360))
    sheet.save(ROOT/'contact-sheet.jpg',quality=95)
    render_frame(0,3,13,0,data['duration'],'').save(ROOT/'poster.png')

def render():
    data=get_timeline();total=data['duration'];frames=math.ceil(total*FPS)
    out=ROOT/'container-haptics-explainer-ja.mp4'
    cmd=['ffmpeg','-y','-v','warning','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-',
         '-i',str(ROOT/'narration.wav'),'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-shortest',str(out)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    current=0;started=time.time()
    try:
        for i in range(frames):
            at=i/FPS
            while current<len(data['scenes'])-1 and at>=data['scenes'][current+1]['start']:current+=1
            s=data['scenes'][current];local=at-s['start']
            im=render_frame(current,local,s['duration'],at,total,caption_at(s,at))
            # Short unobtrusive fade through black at chapter boundaries.
            f=min(smooth(local/.22),smooth((s['duration']-local)/.22))
            if f<1:im=Image.blend(Image.new('RGB',(W,H),BG),im,f)
            proc.stdin.write(im.tobytes())
            if i%(FPS*10)==0:print(f'Render {at:.0f}/{total:.1f}s ({time.time()-started:.1f}s elapsed)',flush=True)
        proc.stdin.close();code=proc.wait()
        if code:raise RuntimeError(f'ffmpeg failed: {code}')
    except BaseException:
        proc.kill();raise
    print(f'Done: {out}',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--audio',action='store_true');ap.add_argument('--preview',action='store_true');ap.add_argument('--render',action='store_true');args=ap.parse_args()
    ROOT.mkdir(parents=True,exist_ok=True)
    if args.audio:asyncio.run(build_audio())
    if args.preview:previews()
    if args.render:render()
