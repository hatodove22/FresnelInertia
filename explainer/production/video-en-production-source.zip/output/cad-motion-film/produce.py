"""English CAD mechanism film: narration, sidecars, media checks and packaging.

Visuals are rendered by render-film.mjs using the same CAD rig as the website.
No original CAD or hardware is changed. See README.md for regeneration.
"""
from pathlib import Path
import argparse
import asyncio
import hashlib
import json
import math
import re
import shutil
import subprocess
import wave
import zipfile

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
STORY = json.loads((ROOT / 'storyboard.json').read_text(encoding='utf-8'))
FILM = ROOT / 'fresnel-inertia-explainer-en.mp4'
FPS, WIDTH, HEIGHT, SAMPLE_RATE = 30, 1920, 1080, 48000


def stamp(t):
    ms = round(t * 1000)
    return f'{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02}.{ms % 1000:03}'


async def build_audio():
    import edge_tts
    cache = ROOT / 'audio'
    cache.mkdir(exist_ok=True)
    audio, timeline = [], []
    cursor = 0.0
    for index, scene in enumerate(STORY['scenes']):
        chunks = [np.zeros(round(0.65 * SAMPLE_RATE), dtype=np.float32)]
        local, captions = 0.65, []
        for line_index, line in enumerate(scene['lines']):
            key = hashlib.sha256((line + STORY['voice'] + STORY['voice_rate'] + STORY['voice_pitch']).encode()).hexdigest()[:12]
            path = cache / f'{index + 1:02}-{line_index + 1:02}-{key}.mp3'
            if not path.exists():
                for attempt in range(3):
                    try:
                        await edge_tts.Communicate(line, voice=STORY['voice'], rate=STORY['voice_rate'], pitch=STORY['voice_pitch']).save(str(path))
                        break
                    except Exception:
                        if attempt == 2:
                            raise
                        await asyncio.sleep(2)
            raw = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le', '-ac', '1', '-ar', str(SAMPLE_RATE), '-'])
            samples = np.frombuffer(raw, dtype=np.float32).copy()
            length = len(samples) / SAMPLE_RATE
            # Keep each cue readable on at most two large subtitle lines.
            # Longer spoken sentences are split into consecutive phrases.
            words = line.split()
            parts = [line]
            if len(line) > 122:
                center = len(words) // 2
                split = min(range(max(1, center - 4), min(len(words), center + 5)),
                            key=lambda i: abs(i-center) - (2 if words[i-1].endswith(('.', ',', ':')) else 0))
                parts = [' '.join(words[:split]), ' '.join(words[split:])]
            part_cursor = 0.0
            for part in parts:
                duration = length * len(part.split()) / len(words)
                captions.append({'start': cursor + local + part_cursor,
                                 'end': cursor + local + part_cursor + duration, 'text': part})
                part_cursor += duration
            chunks += [samples, np.zeros(round(0.3 * SAMPLE_RATE), dtype=np.float32)]
            local += length + 0.3
        target = math.ceil(max(10.5, local + 0.75) * FPS) / FPS
        chunks.append(np.zeros(round((target - local) * SAMPLE_RATE), dtype=np.float32))
        full_scene = np.concatenate(chunks)
        target = len(full_scene) / SAMPLE_RATE
        timeline.append({**scene, 'index': index, 'start': cursor, 'duration': target, 'captions': captions})
        audio.append(full_scene)
        cursor += target
        print(f'{scene["id"]}: {target:.2f}s', flush=True)
    joined = np.concatenate(audio)
    joined *= 0.87 / max(0.01, float(np.abs(joined).max()))
    with wave.open(str(ROOT / 'narration-en.wav'), 'wb') as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(SAMPLE_RATE)
        stream.writeframes((joined * 32767).astype('<i2').tobytes())
    # Bring the narration to a comfortable delivery level without clipping.
    normalized = ROOT / 'narration-normalized.wav'
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(ROOT/'narration-en.wav'),
                    '-af', 'loudnorm=I=-18:TP=-1.5:LRA=7', '-ar', str(SAMPLE_RATE),
                    '-c:a', 'pcm_s16le', str(normalized)], check=True)
    normalized.replace(ROOT / 'narration-en.wav')
    data = {'title': STORY['title'], 'duration': cursor, 'fps': FPS, 'width': WIDTH,
            'height': HEIGHT, 'voice': STORY['voice'], 'voice_disclosure': STORY['disclosure'],
            'audio_normalization': 'loudnorm I=-18 LUFS, TP=-1.5 dBTP, LRA=7',
            'scenes': timeline}
    assert 90 <= cursor <= 120, f'Film timing {cursor:.2f}s falls outside target'
    (ROOT / 'timeline.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    vtt = 'WEBVTT\n\n'
    for scene in timeline:
        for caption in scene['captions']:
            vtt += f'{stamp(caption["start"])} --> {stamp(caption["end"])}\n{caption["text"]}\n\n'
    (ROOT / 'captions-en.vtt').write_text(vtt, encoding='utf-8')
    transcript = STORY['title'] + '\n\n' + STORY['disclosure'] + '\n\n'
    for scene in timeline:
        transcript += f'{stamp(scene["start"])}  {scene["title"]}\n' + '\n'.join(scene['lines']) + '\n\n'
    transcript += ('Source and limits\n'
                   'Actual geometry: Fusion VRSJ2026 v30 CAD export. The CAD contains an older controller outline and actuator envelopes; it is not a complete current electronics assembly.\n'
                   'The film uses illustrative contact-surface commands around identified CAD axes. It does not measure mechanical travel, force, vibration displacement, or perceptual effects.\n'
                   'Glowing vibration markers encode amplitude, not exaggerated physical deflection. The content overlay is explanatory, not live telemetry.\n'
                   'Current haptic content dynamics use the body x/y cross-section. Grip force is nominal, not measured FSR feedback. Android AR remains planned.\n'
                   'Model and hardware facts: docs/00_DESIGN_SPECIFICATION.md, docs/04_HARDWARE_AND_PIN_SPEC.md, docs/16_PROGRESS_STATUS.md.\n'
                   f'Voice: Microsoft Edge TTS, {STORY["voice"]}, rate {STORY["voice_rate"]}, pitch {STORY["voice_pitch"]}. AI-generated; not an impersonation.\n')
    (ROOT / 'transcript-en.txt').write_text(transcript, encoding='utf-8')
    (ROOT / 'transcript-en.md').write_text('# ' + transcript, encoding='utf-8')
    print(f'Total narration timeline: {cursor:.3f}s', flush=True)


def verify():
    timeline = json.loads((ROOT / 'timeline.json').read_text())
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(FILM)], text=True))
    video = next(s for s in probe['streams'] if s['codec_type'] == 'video')
    audio = next(s for s in probe['streams'] if s['codec_type'] == 'audio')
    assert video['codec_name'] == 'h264' and video['width'] == WIDTH and video['height'] == HEIGHT
    assert video['avg_frame_rate'] == '30/1' and video['pix_fmt'] == 'yuv420p'
    assert video['color_range'] == 'tv' and video['color_space'] == 'bt709'
    assert int(video['nb_frames']) == round(timeline['duration'] * FPS)
    assert audio['codec_name'] == 'aac'
    duration = float(probe['format']['duration'])
    assert 90 <= duration <= 120 and abs(duration - timeline['duration']) < .12
    assert abs(float(video['duration']) - float(audio['duration'])) < .12
    decoded = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(FILM), '-f', 'null', '-'], capture_output=True, text=True)
    assert decoded.returncode == 0 and not decoded.stderr.strip(), decoded.stderr
    loudness = subprocess.run(['ffmpeg', '-hide_banner', '-i', str(FILM), '-vn', '-af', 'volumedetect', '-f', 'null', '-'], capture_output=True, text=True)
    mean = float(re.search(r'mean_volume:\s*([-\d.]+)', loudness.stderr).group(1))
    peak = float(re.search(r'max_volume:\s*([-\d.]+)', loudness.stderr).group(1))
    assert -30 < mean < -8 and -6 < peak < 0
    cues = [c for s in timeline['scenes'] for c in s['captions']]
    assert all(0 <= c['start'] < c['end'] <= duration for c in cues)
    assert all(cues[i]['end'] <= cues[i + 1]['start'] + .001 for i in range(len(cues)-1))
    data = FILM.read_bytes()
    assert data.find(b'moov') < data.find(b'mdat')
    motion_checks = {}
    for mode in ['common','differential']:
        first = np.array(Image.open(ROOT/f'motion-{mode}-positive.png').convert('RGB')).astype(np.int16)
        second = np.array(Image.open(ROOT/f'motion-{mode}-negative.png').convert('RGB')).astype(np.int16)
        changed = int((np.max(np.abs(first-second),axis=2)>10).sum())
        assert changed > 1000, f'{mode} CAD motion is not visibly changing'
        motion_checks[mode] = {'changed_pixels_over_10':changed,'same_camera':True,'captions_excluded':True}
    frame_paths, color_checks = [], []
    for scene in timeline['scenes']:
        at = scene['start'] + (1.95 if scene['id']=='spatial-four' else scene['duration'] * .45)
        path = ROOT / f'encoded-scene-{scene["index"]+1:02}.png'
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', str(at), '-i', str(FILM), '-frames:v', '1', str(path)], check=True)
        frame_paths.append(path)
        reference = np.array(Image.open(ROOT/f'scene-{scene["index"]+1:02}.png').convert('RGB')).astype(np.int16)
        encoded = np.array(Image.open(path).convert('RGB')).astype(np.int16)
        # A stationary background patch catches incorrect JPEG range relabeling.
        # CAD-region error also includes the sub-frame pose difference at seek.
        before, after = reference[400, 5], encoded[400, 5]
        assert np.max(np.abs(before-after)) <= 3, 'Encoded background range changed'
        color_checks.append({'scene':scene['id'], 'reference_background_rgb':before.tolist(),
                             'encoded_background_rgb':after.tolist(),
                             'cad_region_mean_absolute_rgb_error':round(float(np.abs(reference[250:810,500:1420]-encoded[250:810,500:1420]).mean()),3)})
    sheet = Image.new('RGB', (1280, 4 * 360), '#101319')
    for index, path in enumerate(frame_paths):
        sheet.paste(Image.open(path).convert('RGB').resize((640, 360)), ((index % 2)*640, (index // 2)*360))
    sheet.save(ROOT / 'contact-sheet.jpg', quality=94)
    result = {'file': FILM.name, 'bytes': len(data), 'duration_s': duration,
              'video': {k:video[k] for k in ['codec_name','width','height','avg_frame_rate','pix_fmt','color_range','color_space','color_transfer','color_primaries','side_data_list','duration','nb_frames'] if k in video},
              'audio': {k:audio[k] for k in ['codec_name','sample_rate','channels','duration']},
              'full_decode': 'pass', 'faststart': True, 'mean_volume_db': mean, 'peak_volume_db': peak,
              'subtitle_cues': len(cues), 'subtitle_timing': 'pass',
              'cad_motion_frame_checks':motion_checks,
              'encoded_color_comparison':color_checks,
              'cad_source': 'Actual exported Fusion CAD via shared explainer/src/device.ts rig',
              'commands': 'illustrative; not hardware measurement', 'synthetic_voice': True,
              'new_hardware_verification': False, 'sha256':hashlib.sha256(data).hexdigest()}
    layout_path=ROOT/'layout-verification.json'
    if layout_path.exists():
        result['subtitle_layout']=json.loads(layout_path.read_text())
    (ROOT / 'verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2), flush=True)


def publish():
    media = REPO / 'explainer/public/media'
    production = REPO / 'explainer/production'
    media.mkdir(parents=True, exist_ok=True)
    production.mkdir(parents=True, exist_ok=True)
    for name in [FILM.name, 'captions-en.vtt', 'transcript-en.txt', 'poster-en.png']:
        shutil.copy2(ROOT / name, media / name)
    for source, name in [('README.md','VIDEO_EN_README.md'), ('transcript-en.md','transcript-en.md'),
                         ('verification.json','video-en-verification.json')]:
        shutil.copy2(ROOT / source, production / name)
    # Include actual dependencies used by the film; cached frames and binaries
    # are omitted. Cached narration is included so regeneration is offline.
    archive = ROOT / 'cad-motion-film-source.zip'
    sources = [p for p in ROOT.iterdir() if p.suffix in ['.py','.mjs','.json','.md','.txt','.vtt','.wav']]
    sources += list((ROOT/'audio').glob('*.mp3'))
    sources += [REPO/'explainer/film-stage.html', REPO/'explainer/src/film-stage.ts',
                REPO/'explainer/src/device.ts', REPO/'explainer/src/deviceRig.ts',
                REPO/'explainer/src/mechanismMotion.ts', REPO/'explainer/package.json', REPO/'explainer/package-lock.json']
    # Rig modules and exact geometry are included once they exist. README gives
    # repository paths for any additional website dependencies.
    sources += list((REPO/'explainer/src').glob('*rig*'))
    sources += list((REPO/'explainer/src').glob('*cad*'))
    for asset in (REPO/'explainer/public').rglob('*'):
        if asset.is_file() and asset.suffix in ['.glb','.json'] and 'media' not in asset.parts:
            sources.append(asset)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for source in sorted(set(sources)):
            if source.exists(): z.write(source, source.relative_to(REPO))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name in ['explainer/src/device.ts', 'explainer/src/deviceRig.ts',
                     'explainer/src/mechanismMotion.ts', 'explainer/src/film-stage.ts',
                     'explainer/public/models/device-cad.glb',
                     'explainer/public/models/device-kinematics.json',
                     'output/cad-motion-film/timeline.json',
                     'output/cad-motion-film/narration-en.wav']:
            assert name in z.namelist(), f'Production source is missing {name}'
    shutil.copy2(archive, production / 'video-en-production-source.zip')
    print(f'Published English media and {archive.stat().st_size} byte source archive; Japanese media preserved.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--audio', action='store_true')
    parser.add_argument('--verify', action='store_true')
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    if args.audio: asyncio.run(build_audio())
    if args.verify: verify()
    if args.publish: publish()
