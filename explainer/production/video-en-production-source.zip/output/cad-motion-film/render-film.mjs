import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {once} from 'node:events';

const here=path.dirname(fileURLToPath(import.meta.url));
const repo=path.resolve(here,'../..');
const require=createRequire(path.join(repo,'explainer/package.json'));
const {chromium}=require('playwright');
const {createServer}=await import(pathToFileURL(require.resolve('vite')).href);
const timeline=JSON.parse(await fs.readFile(path.join(here,'timeline.json'),'utf8'));
const server=await createServer({root:path.join(repo,'explainer'),configFile:false,optimizeDeps:{entries:[path.join(repo,'explainer/film-stage.html')]},server:{host:'127.0.0.1',port:4177,strictPort:false,fs:{allow:[repo]}},
  plugins:[{name:'film-timeline',configureServer(server){server.middlewares.use((req,res,next)=>{
    if(req.url==='/__film/timeline.json'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(timeline));}else next();
  });}}],logLevel:'warn'});
await server.listen();
const url=server.resolvedUrls.local[0]+'film-stage.html';
const browser=await chromium.launch({headless:true,channel:'chrome',args:['--force-device-scale-factor=1']});
const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>{errors.push(String(e));console.error(e);});
let encoder;
try{
  await page.goto(url,{waitUntil:'networkidle'});
  await page.waitForFunction(()=>window.filmReady,null,{timeout:60000});
  await page.evaluate(()=>document.fonts.ready);
  // The shared viewer's asset readiness must be established before any frame.
  await page.waitForFunction(()=>document.querySelector('canvas')?.dataset.ready==='true',null,{timeout:60000});
  const captionLayouts=[];
  for(const scene of timeline.scenes)for(const cue of scene.captions){
    await page.evaluate(t=>window.setFilmFrame(t),(cue.start+cue.end)/2);
    const box=await page.evaluate(()=>{const c=document.querySelector('#caption').getBoundingClientRect();return{x:c.x,y:c.y,width:c.width,height:c.height,bottom:c.bottom};});
    if(box.x<70||box.y<908||box.bottom>1080||box.height>122)throw new Error(`Subtitle overflows: ${cue.text}`);
    captionLayouts.push({text:cue.text,...box});
  }
  await fs.writeFile(path.join(here,'layout-verification.json'),JSON.stringify({checkedCaptions:captionLayouts.length,allInsideSubtitleBand:true,maxLines:2,captionLayouts},null,2)+'\n');
  const shots=timeline.scenes.map(s=>({name:`scene-${String(s.index+1).padStart(2,'0')}.png`,time:s.start+(s.id==='spatial-four'?1.95:s.duration*.45)}));
  const spatial=timeline.scenes.find(s=>s.id==='spatial-four');
  for(let i=0;i<4;i++)shots.push({name:`vibration-location-${i+1}.png`,time:spatial.start+.4+i*1.55});
  shots.push({name:'poster-en.png',time:4});
  for(const shot of shots){
    await page.evaluate(t=>window.setFilmFrame(t),shot.time);
    if(shot.name==='poster-en.png')await page.evaluate(()=>{document.querySelector('#caption').textContent='2 tilting contact surfaces · 4 vibration elements';});
    await page.screenshot({path:path.join(here,shot.name)});
  }
  // Raw canvas images isolate mechanical movement from changing captions.
  for(const mode of ['common','differential']){
    const scene=timeline.scenes.find(s=>s.id===mode);
    for(const[sign,offset]of[['positive',Math.PI/2/.85],['negative',Math.PI*1.5/.85]]){
      await page.evaluate(t=>window.setFilmFrame(t),scene.start+offset);
      const png=await page.evaluate(()=>document.querySelector('canvas').toDataURL('image/png').split(',')[1]);
      await fs.writeFile(path.join(here,`motion-${mode}-${sign}.png`),Buffer.from(png,'base64'));
    }
  }
  if(errors.length)throw new Error(errors.join('\n'));
  if(process.argv.includes('--preview')){console.log('All eight scene previews and poster rendered.');}
  else{
    const args=['-y','-v','warning','-f','image2pipe','-framerate','30','-vcodec','mjpeg','-i','-',
      '-i',path.join(here,'narration-en.wav'),
      // Chrome's JPEG frames are full-range JFIF. Convert samples as well as
      // declaring delivery metadata; relabeling alone would lift the blacks.
      '-vf','scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p',
      '-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p',
      '-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
      '-c:a','aac','-b:a','160k','-movflags','+faststart','-shortest',path.join(here,'fresnel-inertia-explainer-en.mp4')];
    encoder=spawn('ffmpeg',args,{stdio:['pipe','inherit','inherit']});
    const complete=once(encoder,'exit');
    const count=Math.ceil(timeline.duration*30);const start=Date.now();
    for(let i=0;i<count;i++){
      await page.evaluate(t=>window.setFilmFrame(t),i/30);
      const data=await page.screenshot({type:'jpeg',quality:93});
      if(!encoder.stdin.write(data))await once(encoder.stdin,'drain');
      if(i%150===0)console.log(`Film ${Math.round(i/30)}/${timeline.duration.toFixed(1)}s; ${((Date.now()-start)/1000).toFixed(0)}s elapsed`);
    }
    encoder.stdin.end();const[code]=await complete;
    if(code!==0)throw new Error(`ffmpeg exited ${code}`);
    if(errors.length)throw new Error(errors.join('\n'));
    console.log('Complete English CAD film rendered.');
  }
}finally{
  if(encoder&&encoder.exitCode===null)encoder.kill();
  await browser.close();await server.close();
}
